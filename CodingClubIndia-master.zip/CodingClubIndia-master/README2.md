Tell about your experience.
By adding name and comment below..

Mohit Ishpunyani(Haryana)
I got a glimpse of git version control by the aid of CodingClubIndia today

Navansh Khandelwal(Jaipur)
Due to Mukul bhaiya,I learnt something new today


Anand Pandey(Chandigarh)
I learnt something new today...Thanx to coding club


Pranjal Agrawal(jaipur)
Thanks CodingClubIndia to Have  a very interective session . It is very helpful for me.
Now i can enter in open source world and can give contributions in it


Pankaj (Haryana)
Studying CS hons at Dyal Singh College 2nd YR

Alaukik Varu>>>>>>> mastern(dehradun)
Thanks CodingClubIndia to Have  a very interective session . It is very helpful for me.
Now i can enter in open source world and can give contributions in it
kudos.

It was fun learning new things with CodingClub. ThankYou Guys.
Rajanbir Singh Ghumaan

