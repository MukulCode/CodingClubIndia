#include <iostream>
using namespace std;

int main() {
    int t;
    cin>>t;
    while(t--)
    {
        int x;
        cin>>x;
        cout<<(x*10)<<endl;
    }
	// your code goes here
	return 0;
}
