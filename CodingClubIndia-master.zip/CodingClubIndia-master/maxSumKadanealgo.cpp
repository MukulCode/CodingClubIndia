#include<iostream>
using namespace std;
int maxSum(int arr[],int n)
{
   e
}
int main()
{
    int arr[]={1,2,3,4,5,6,7,8,9,0};
    int n=sizeof(arr)/sizeof(int);
    cout<<"largest sum is "<<maxSum(arr,n);

    return 0;
}