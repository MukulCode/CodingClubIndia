// Hello World in Kotlin

fun main(args: Array<String>){
	println("Hello World")
}
