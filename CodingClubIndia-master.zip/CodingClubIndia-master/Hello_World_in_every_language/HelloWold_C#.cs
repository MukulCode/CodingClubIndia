// Hello World in C#

namespace HelloWorld
{
    class Hello{
        static void Main(string[] args){
              System.Console.WriteLine("Hello World!");
        }
    }
}
