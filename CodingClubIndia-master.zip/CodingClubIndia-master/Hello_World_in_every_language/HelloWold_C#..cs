// Hello, World in C#...
// C# is pronounced as 'C-Sharp'.

namespace HelloWorld
{
    class Hello{
        static void Main(string[] args){
              System.Console.WriteLine("Hello World!");
        }
    }
}
