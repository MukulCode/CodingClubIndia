Constraints
// 1≤T≤100
// 3≤N≤1000
// Subtasks
// Sample Input 1 
// 2
// 4
// 3
// Sample Output 1 
// 1001
// 010
// Explanation
// Test case 1: A binary string satisfying both the conditions is 1001. The count of 01 as well as 10 subsequences in the string is 2.

// Test case 2: A binary string satisfying both the conditions is 010. The count of 01 as well as 10 subsequences in the string is 1.