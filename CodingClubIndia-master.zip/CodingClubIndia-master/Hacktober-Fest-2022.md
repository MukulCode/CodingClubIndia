###Rules
- Everybody is requested to state their name, and write how they came across Mukul Bhaiya
- Contributors shall not modify with other people's entries

##How did you come across this repository?
I, [Tanay Kumar](www.github.com/Tanaykmr) came across Mukul Bhaiya a few days ago when I attended his GDSC MSIT meet on intro to open source and all about HacktoberFest
