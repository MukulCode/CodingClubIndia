#include<iostream>
using namespace std;
int main()
{
cout<<"Hello World From AMAN\n";
}
