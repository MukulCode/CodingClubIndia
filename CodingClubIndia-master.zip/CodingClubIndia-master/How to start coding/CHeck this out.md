Just get started with a good Udemy course/ check out harvard's CS50 on YouTube for free!

Here are some tips from my side.
Choose your language.
Learn basics.
Learn the DSA. (Don't wait for completeion).
Learn some basic maths (hacker rank where you can start for maths and strengthen your coding concept).
Use codechef and leetcode. Attend all the contests and after contest upsolving and evaluation is a must.
And final and Last Practice !!!!!
