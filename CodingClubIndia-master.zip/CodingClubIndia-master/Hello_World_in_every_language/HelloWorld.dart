void main () 
{
  String str = "Hello World";
  print(str); 
}
